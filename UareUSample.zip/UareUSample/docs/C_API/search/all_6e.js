var searchData=
[
  ['name',['name',['../structdpfpdd__dev__info.html#ab6751f0fdbb337a1feb37aff0de469bb',1,'dpfpdd_dev_info']]]
];
