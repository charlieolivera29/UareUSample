var searchData=
[
  ['error',['error',['../structdpfpdd__capture__callback__data__0.html#a11614f44ef4d939bdd984953346a7572',1,'dpfpdd_capture_callback_data_0']]],
  ['ext_5fblock',['ext_block',['../structdpfj__fmd__view__params.html#a442f5de2bab028edea7d8c6f62469ce2',1,'dpfj_fmd_view_params']]],
  ['ext_5fblock_5flength',['ext_block_length',['../structdpfj__fmd__view__params.html#a64e9a7222c0e68a7a33cd9fca0bb07ad',1,'dpfj_fmd_view_params']]]
];
