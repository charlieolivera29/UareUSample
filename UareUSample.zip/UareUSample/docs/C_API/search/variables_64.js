var searchData=
[
  ['data',['data',['../structdpfpdd__dev__status.html#aebcf2224b8cadd92b9b5781002281289',1,'dpfpdd_dev_status']]],
  ['data_5flength',['data_length',['../structdpfj__fid__view__params.html#a6e455df9b373a99a0b22b05dd76c38b1',1,'dpfj_fid_view_params']]],
  ['descr',['descr',['../structdpfpdd__dev__info.html#a872e0829f70e83346ce8cc74d49239ac',1,'dpfpdd_dev_info']]]
];
