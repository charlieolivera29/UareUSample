var searchData=
[
  ['finger_5fcnt',['finger_cnt',['../structdpfj__fid__record__params.html#adc702f23151c7bc13402ac194719c969',1,'dpfj_fid_record_params']]],
  ['finger_5fdetected',['finger_detected',['../structdpfpdd__dev__status.html#a77eacac9b26122f5df269a69efbc0102',1,'dpfpdd_dev_status']]],
  ['finger_5fposition',['finger_position',['../structdpfj__fid__view__params.html#a3353850c3dcbea73157ca81524cd18c3',1,'dpfj_fid_view_params::finger_position()'],['../structdpfj__fmd__view__params.html#a3353850c3dcbea73157ca81524cd18c3',1,'dpfj_fmd_view_params::finger_position()']]],
  ['fmd_5fidx',['fmd_idx',['../structdpfj__candidate.html#a4542228c923c2ca6d1ab3059db8af115',1,'dpfj_candidate']]],
  ['fw_5fver',['fw_ver',['../structdpfpdd__hw__version.html#acf8eb66682328970bdbcbdf52d4061bf',1,'dpfpdd_hw_version']]]
];
