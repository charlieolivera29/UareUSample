var searchData=
[
  ['acquisition_5flevel',['acquisition_level',['../structdpfj__fid__record__params.html#a7e147a81167b0784f701190ddb8518bd',1,'dpfj_fid_record_params']]],
  ['addr',['addr',['../structdpfpdd__iomap.html#af2d98bb0b152ca3d254d1c534236c2e6',1,'dpfpdd_iomap']]],
  ['api_5fver',['api_ver',['../structdpfj__version.html#a859a52910fa0c52ff97af92700831125',1,'dpfj_version::api_ver()'],['../structdpfpdd__version.html#ad726e7cdfbbceb915532fc6d2687c8be',1,'dpfpdd_version::api_ver()']]]
];
