var searchData=
[
  ['vendor_5fid',['vendor_id',['../structdpfpdd__hw__id.html#a8dd854779c738741e0c68caad12fc8a6',1,'dpfpdd_hw_id']]],
  ['vendor_5fname',['vendor_name',['../structdpfpdd__hw__descr.html#a2f430dee99479f60cd65070c55720d01',1,'dpfpdd_hw_descr']]],
  ['ver',['ver',['../structdpfpdd__dev__info.html#a833741236b10039ef939218ba683d1fa',1,'dpfpdd_dev_info']]],
  ['view_5fcnt',['view_cnt',['../structdpfj__fid__view__params.html#a22b172b6e06ba45657d8db71d7ac3efe',1,'dpfj_fid_view_params::view_cnt()'],['../structdpfj__fmd__record__params.html#a22b172b6e06ba45657d8db71d7ac3efe',1,'dpfj_fmd_record_params::view_cnt()']]],
  ['view_5fdata',['view_data',['../structdpfj__fid__view__params.html#acd8e12b17166f6035d4595a0ba7ef454',1,'dpfj_fid_view_params']]],
  ['view_5fidx',['view_idx',['../structdpfj__candidate.html#ac029bdffa912e840c2c3d9b5e2673132',1,'dpfj_candidate']]],
  ['view_5fnumber',['view_number',['../structdpfj__fid__view__params.html#add872c76931d95983575abfb6a782d96',1,'dpfj_fid_view_params::view_number()'],['../structdpfj__fmd__view__params.html#add872c76931d95983575abfb6a782d96',1,'dpfj_fmd_view_params::view_number()']]]
];
