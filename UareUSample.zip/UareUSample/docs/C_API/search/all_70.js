var searchData=
[
  ['piv_5fcompliant',['piv_compliant',['../structdpfpdd__dev__caps.html#aea717f5e29034fa4bd14ccacbb66badd',1,'dpfpdd_dev_caps']]],
  ['product_5fid',['product_id',['../structdpfpdd__hw__id.html#a7cc759e6106a68b56401f2323a5c5c2a',1,'dpfpdd_hw_id']]],
  ['product_5fname',['product_name',['../structdpfpdd__hw__descr.html#a4a4962d7015cfae8b35343466f9df1b2',1,'dpfpdd_hw_descr']]]
];
