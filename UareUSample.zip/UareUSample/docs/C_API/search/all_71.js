var searchData=
[
  ['quality',['quality',['../structdpfj__fid__view__params.html#a6b9888afa18cb95420dd38f456a2f926',1,'dpfj_fid_view_params::quality()'],['../structdpfj__fmd__view__params.html#a6b9888afa18cb95420dd38f456a2f926',1,'dpfj_fmd_view_params::quality()'],['../structdpfpdd__capture__result.html#a4d983a65851cc28de88b3c4901d4a667',1,'dpfpdd_capture_result::quality()']]]
];
