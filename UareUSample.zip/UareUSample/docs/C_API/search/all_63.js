var searchData=
[
  ['can_5fcapture_5fimage',['can_capture_image',['../structdpfpdd__dev__caps.html#aee35269bbcd2aa31dc30d99b136f7d74',1,'dpfpdd_dev_caps']]],
  ['can_5fextract_5ffeatures',['can_extract_features',['../structdpfpdd__dev__caps.html#af701ffeb1d8b30d73e83dbe67306bb4a',1,'dpfpdd_dev_caps']]],
  ['can_5fidentify',['can_identify',['../structdpfpdd__dev__caps.html#aa1767e44d04a87339016b3c1dee01638',1,'dpfpdd_dev_caps']]],
  ['can_5fmatch',['can_match',['../structdpfpdd__dev__caps.html#ab29d3810bf8ba86b5bcae203b16f310c',1,'dpfpdd_dev_caps']]],
  ['can_5fstream_5fimage',['can_stream_image',['../structdpfpdd__dev__caps.html#a4f825f114d8ea17578f855faf97adfbb',1,'dpfpdd_dev_caps']]],
  ['capture_5fdevice_5fid',['capture_device_id',['../structdpfj__fid__record__params.html#a9f1d315fdd643252829a621514afe0bc',1,'dpfj_fid_record_params']]],
  ['capture_5fequipment_5fcomp',['capture_equipment_comp',['../structdpfj__fmd__record__params.html#ad3e9f1ab7ce90ef853f921a1b6864d45',1,'dpfj_fmd_record_params']]],
  ['capture_5fequipment_5fid',['capture_equipment_id',['../structdpfj__fmd__record__params.html#a5d0c74403dc6fbc766c0c76814574c08',1,'dpfj_fmd_record_params']]],
  ['capture_5fparm',['capture_parm',['../structdpfpdd__capture__callback__data__0.html#a9f303aecd16beec22e975bb084b3c9bf',1,'dpfpdd_capture_callback_data_0']]],
  ['capture_5fresult',['capture_result',['../structdpfpdd__capture__callback__data__0.html#acf50a75e2ae5b8f42d45f3ecdf8dbb71',1,'dpfpdd_capture_callback_data_0']]],
  ['cbeff_5fid',['cbeff_id',['../structdpfj__fid__record__params.html#aa60c10065c83044537ab3778e8f999b4',1,'dpfj_fid_record_params::cbeff_id()'],['../structdpfj__fmd__record__params.html#aa60c10065c83044537ab3778e8f999b4',1,'dpfj_fmd_record_params::cbeff_id()']]],
  ['compression',['compression',['../structdpfj__fid__record__params.html#ad180079f62b44e49ec672c9ef6e078b3',1,'dpfj_fid_record_params']]]
];
