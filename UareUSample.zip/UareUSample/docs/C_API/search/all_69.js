var searchData=
[
  ['id',['id',['../structdpfpdd__dev__info.html#a3ada9004bf478684ebb05e9fec25104a',1,'dpfpdd_dev_info']]],
  ['image_5fdata',['image_data',['../structdpfpdd__capture__callback__data__0.html#a19f813e1b1c9ec34cd59babce2354837',1,'dpfpdd_capture_callback_data_0']]],
  ['image_5ffmt',['image_fmt',['../structdpfpdd__capture__param.html#aa73df8cdd62d12fa1a9f4c9c75766ec2',1,'dpfpdd_capture_param']]],
  ['image_5fproc',['image_proc',['../structdpfpdd__capture__param.html#ab42a099b091643dee732a0262bc245da',1,'dpfpdd_capture_param']]],
  ['image_5fres',['image_res',['../structdpfj__fid__record__params.html#ac86b655372e0a06e0dd74c48f58b6b40',1,'dpfj_fid_record_params::image_res()'],['../structdpfpdd__capture__param.html#ac86b655372e0a06e0dd74c48f58b6b40',1,'dpfpdd_capture_param::image_res()']]],
  ['image_5fsize',['image_size',['../structdpfpdd__capture__callback__data__0.html#aba4f60eb4f8494805d4f8cd1d8415afb',1,'dpfpdd_capture_callback_data_0']]],
  ['impression_5ftype',['impression_type',['../structdpfj__fid__view__params.html#ae7a2fadca36a6d6bf54e69765206bd52',1,'dpfj_fid_view_params::impression_type()'],['../structdpfj__fmd__view__params.html#ae7a2fadca36a6d6bf54e69765206bd52',1,'dpfj_fmd_view_params::impression_type()']]],
  ['indicator_5ftype',['indicator_type',['../structdpfpdd__dev__caps.html#aafd79170117334486f713729586e641d',1,'dpfpdd_dev_caps']]],
  ['info',['info',['../structdpfpdd__capture__result.html#acaaa3ba766879e4f00af6e7f19787ac0',1,'dpfpdd_capture_result']]]
];
