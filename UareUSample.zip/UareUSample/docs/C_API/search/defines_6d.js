var searchData=
[
  ['max_5fdevice_5fname_5flength',['MAX_DEVICE_NAME_LENGTH',['../dpfpdd_8h.html#a1f6c89459abdd1916208c926a4df3ae4',1,'dpfpdd.h']]],
  ['max_5ffmd_5fsize',['MAX_FMD_SIZE',['../dpfj_8h.html#aec88637fb49a8851d8e9d69226cf8993',1,'dpfj.h']]],
  ['max_5fstr_5flength',['MAX_STR_LENGTH',['../dpfpdd_8h.html#aaa695591372841e2c5580e4ed0f3620f',1,'dpfpdd.h']]]
];
