var searchData=
[
  ['bcd_5frev',['bcd_rev',['../structdpfpdd__hw__version.html#a583c0565d03b9526a69aef23aadf616c',1,'dpfpdd_hw_version']]],
  ['bpp',['bpp',['../structdpfj__fid__record__params.html#a54b1f406bd10413e14f8279d45da6e41',1,'dpfj_fid_record_params::bpp()'],['../structdpfpdd__image__info.html#a54b1f406bd10413e14f8279d45da6e41',1,'dpfpdd_image_info::bpp()']]],
  ['buff',['buff',['../structdpfpdd__iomap.html#af4739e7f2658d16b316e482da4cbbc28',1,'dpfpdd_iomap']]]
];
