var searchData=
[
  ['record_5flength',['record_length',['../structdpfj__fid__record__params.html#a05fbc1d3a25168dc8b758563716e65d4',1,'dpfj_fid_record_params::record_length()'],['../structdpfj__fmd__record__params.html#a05fbc1d3a25168dc8b758563716e65d4',1,'dpfj_fmd_record_params::record_length()']]],
  ['res',['res',['../structdpfpdd__image__info.html#aa5ef9ac1a2ceac0d62c66bae9ed55dbe',1,'dpfpdd_image_info']]],
  ['resolution',['resolution',['../structdpfj__fmd__record__params.html#ad1142e614ab2dee0eb5018eef4b94377',1,'dpfj_fmd_record_params']]],
  ['resolution_5fcnt',['resolution_cnt',['../structdpfpdd__dev__caps.html#a66cd1352dc2ab6526f2a3048d276c003',1,'dpfpdd_dev_caps']]],
  ['resolutions',['resolutions',['../structdpfpdd__dev__caps.html#a9254275f416ec5cc6957d07512c6ca75',1,'dpfpdd_dev_caps']]]
];
