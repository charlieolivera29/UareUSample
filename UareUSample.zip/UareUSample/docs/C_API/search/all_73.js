var searchData=
[
  ['scale_5funits',['scale_units',['../structdpfj__fid__record__params.html#ae58a84e235d58a65e7377dd35f061d9e',1,'dpfj_fid_record_params']]],
  ['scan_5fres',['scan_res',['../structdpfj__fid__record__params.html#a4204766808a7f17601aa38ea626f71a1',1,'dpfj_fid_record_params']]],
  ['score',['score',['../structdpfpdd__capture__result.html#a9dffb288f0f2281a0b9abbd8efaa5a18',1,'dpfpdd_capture_result']]],
  ['serial_5fnum',['serial_num',['../structdpfpdd__hw__descr.html#a338885583b221d272f1e126f941a4b51',1,'dpfpdd_hw_descr']]],
  ['size',['size',['../structdpfj__version.html#aac913b3a1f6ef005d66bf7a84428773e',1,'dpfj_version::size()'],['../structdpfj__candidate.html#aac913b3a1f6ef005d66bf7a84428773e',1,'dpfj_candidate::size()'],['../structdpfpdd__version.html#aac913b3a1f6ef005d66bf7a84428773e',1,'dpfpdd_version::size()'],['../structdpfpdd__dev__info.html#aac913b3a1f6ef005d66bf7a84428773e',1,'dpfpdd_dev_info::size()'],['../structdpfpdd__dev__caps.html#aac913b3a1f6ef005d66bf7a84428773e',1,'dpfpdd_dev_caps::size()'],['../structdpfpdd__dev__status.html#aac913b3a1f6ef005d66bf7a84428773e',1,'dpfpdd_dev_status::size()'],['../structdpfpdd__capture__param.html#aac913b3a1f6ef005d66bf7a84428773e',1,'dpfpdd_capture_param::size()'],['../structdpfpdd__image__info.html#aac913b3a1f6ef005d66bf7a84428773e',1,'dpfpdd_image_info::size()'],['../structdpfpdd__capture__result.html#aac913b3a1f6ef005d66bf7a84428773e',1,'dpfpdd_capture_result::size()'],['../structdpfpdd__capture__callback__data__0.html#aac913b3a1f6ef005d66bf7a84428773e',1,'dpfpdd_capture_callback_data_0::size()']]],
  ['status',['status',['../structdpfpdd__dev__status.html#a357860efa3c1571768cb3dae106b87c6',1,'dpfpdd_dev_status']]],
  ['success',['success',['../structdpfpdd__capture__result.html#a6538a52840afd2ad6aba6a1ea5d89e50',1,'dpfpdd_capture_result']]]
];
