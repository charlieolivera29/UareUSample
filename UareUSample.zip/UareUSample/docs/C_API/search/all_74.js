var searchData=
[
  ['technology',['technology',['../structdpfpdd__dev__info.html#ae7301b589c6a85de1855f1b0d3f3cde7',1,'dpfpdd_dev_info']]]
];
